package com.biblioteca.mvc;

import java.util.List;
import java.util.Scanner;

public class VistaConsola {
    
    private Scanner scanner;

    public VistaConsola() {
        this.scanner = new Scanner(System.in);
    }

    public int mostrarMenu() {
        System.out.println("\n--- MENÚ BIBLIOTECA ---");
        System.out.println("1. Agregar un nuevo libro");
        System.out.println("2. Mostrar todos los libros");
        System.out.println("3. Salir");
        System.out.print("Seleccione una opción: ");
        int opcion = -1; 
        try {
            opcion = scanner.nextInt();
        } catch (Exception e) {
            System.out.println("Error: Por favor, ingrese un número válido.");
        } finally {
            scanner.nextLine(); 
        }
        return opcion;
    }

    public Libro solicitarDatosLibro() {
        System.out.print("Ingrese el título del libro: ");
        String titulo = scanner.nextLine();
        System.out.print("Ingrese el autor del libro: ");
        String autor = scanner.nextLine();
        System.out.print("Ingrese el ISBN del libro: ");
        String isbn = scanner.nextLine();
        return new Libro(titulo, autor, isbn);
    }

    public void mostrarListaCompleta(List<Libro> libros) {
        System.out.println("\n--- LISTA DE LIBROS ---");
        if (libros.isEmpty()) {
            System.out.println("La biblioteca está vacía.");
        } else {
            for (Libro libro : libros) {
                System.out.println(libro.toString()); 
            }
        }
    }

    public void mostrarMensaje(String mensaje) {
        System.out.println(mensaje);
    }
}