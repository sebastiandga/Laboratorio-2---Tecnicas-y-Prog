package com.biblioteca.mvc;

import java.util.List;

public class LibroControlador {

    private LibroDAO modelo;
    private VistaConsola vista;

    public LibroControlador(LibroDAO modelo, VistaConsola vista) {
        this.modelo = modelo;
        this.vista = vista;
    }

    public void iniciarAplicacion() {
        boolean salir = false;
        while (!salir) {
            int opcion = vista.mostrarMenu();

            switch (opcion) {
                case 1:
                    agregarNuevoLibro();
                    break;
                case 2:
                    verTodosLosLibros();
                    break;
                case 3:
                    salir = true;
                    vista.mostrarMensaje("Gracias por usar la biblioteca. ¡Hasta pronto!");
                    break;
                default:
                    vista.mostrarMensaje("Opción no válida. Por favor, intente de nuevo.");
            }
        }
    }

    private void agregarNuevoLibro() {
        Libro nuevoLibro = vista.solicitarDatosLibro();

        modelo.agregarLibro(nuevoLibro);

        vista.mostrarMensaje("¡Libro agregado exitosamente!");
    }

    private void verTodosLosLibros() {
        List<Libro> biblioteca = modelo.obtenerTodosLosLibros();

        vista.mostrarListaCompleta(biblioteca);
    }

    public static void main(String[] args) {
        LibroDAO modelo = new LibroDAO();
        VistaConsola vista = new VistaConsola();
        LibroControlador controlador = new LibroControlador(modelo, vista);

        controlador.iniciarAplicacion();
    }
}
