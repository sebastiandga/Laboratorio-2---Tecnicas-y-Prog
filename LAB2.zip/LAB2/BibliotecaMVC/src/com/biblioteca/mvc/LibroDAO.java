package com.biblioteca.mvc;

import java.util.ArrayList;
import java.util.List;

public class LibroDAO {
    private List<Libro> biblioteca = new ArrayList<>();

    public void agregarLibro(Libro libro) {
        biblioteca.add(libro);
    }

    public List<Libro> obtenerTodosLosLibros() {
        return new ArrayList<>(biblioteca);
    }
    
    public Libro buscarLibroPorIsbn(String isbn) {
        for (Libro libro : biblioteca) {
            if (libro.getIsbn().equals(isbn)) {
                return libro;
            }
        }
        return null; 
    }
}