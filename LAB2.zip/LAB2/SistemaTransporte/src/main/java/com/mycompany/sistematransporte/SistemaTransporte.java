/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistematransporte;

public class SistemaTransporte {

    
    public static void procesarViaje(SistemaTarifario vehiculo, double km) {
        System.out.println("--- Iniciando procesamiento de viaje ---");
        vehiculo.mostrarRuta();
        double tarifaCobrada = vehiculo.calcularTarifa(km);
        System.out.println("Distancia: " + km + " km. Tarifa a cobrar: $" + tarifaCobrada + " COP");
        System.out.println("--------------------------------------\n");
    }

     
    public static void main(String[]args) {
        SistemaTarifario miBus = new BusArticulado();
        
        SistemaTarifario miTeleferico = new Teleferico();
        
        System.out.println("===== PRUEBAS DEL SISTEMA DE TRANSPORTE =====");
        
        procesarViaje(miBus, 5); 
        
        procesarViaje(miTeleferico, 2);
    }
}