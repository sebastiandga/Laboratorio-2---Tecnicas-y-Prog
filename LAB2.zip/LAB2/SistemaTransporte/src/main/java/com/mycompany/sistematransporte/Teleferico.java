/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistematransporte;


public class Teleferico implements SistemaTarifario {

    private final double TARIFA_BASE = 1000.0;
    private final double COSTO_POR_KM = 500.0;

    @Override
    public double calcularTarifa(double distancia) {
        return TARIFA_BASE + (COSTO_POR_KM * distancia);
    }

    @Override
    public void mostrarRuta() {
        System.out.println("Ruta de conexión veredal (tarifa variable, base $" + TARIFA_BASE + " COP)");
    }
}
